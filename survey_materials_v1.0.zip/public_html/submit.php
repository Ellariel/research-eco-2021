﻿<?php
//$k = '{"test":[["5","7"],["5","7"],["5","5"],["1","7"],["3","7"],["4","6"],["5","6"],["6","5"],["2","5"],["6","7"],["5","5"],["1","7"],["1","5"],["5","7"],["6","7"],["6","6"],["5","6"],["3","6"],["4","5"],["4","7"],["4","7"],["1","6"],["6","7"],["2","7"],["5","7"],["6","5"],["2","6"],["2","7"],["6","6"],["3","5"],["3","7"],["6","7"]],"times":[2093],"valence":[5],"imgurl_1":["images/pos/017.jpg","images/pos/006.jpg","images/pos/009.jpg","images/rec/010.jpg","images/sho/018.jpg","images/tra/014.jpg","images/pos/002.jpg","images/neg/010.jpg","images/sav/015.jpg","images/neg/007.jpg","images/pos/003.jpg","images/rec/012.jpg","images/rec/004.jpg","images/pos/010.jpg","images/neg/004.jpg","images/neg/014.jpg","images/pos/005.jpg","images/sho/010.jpg","images/tra/007.jpg","images/tra/008.jpg","images/tra/005.jpg","images/rec/015.jpg","images/neg/005.jpg","images/sav/014.jpg","images/pos/001.jpg","images/neg/003.jpg","images/sav/009.jpg","images/sav/004.jpg","images/neg/002.jpg","images/sho/014.jpg","images/sho/003.jpg","images/neg/009.jpg"],"imgurl_2":["images/neut/011.jpg","images/neut/002.jpg","images/pos/019.jpg","images/neut/007.jpg","images/neut/013.jpg","images/neg/013.jpg","images/neg/001.jpg","images/pos/013.jpg","images/pos/007.jpg","images/neut/006.jpg","images/pos/008.jpg","images/neut/014.jpg","images/pos/011.jpg","images/neut/001.jpg","images/neut/012.jpg","images/neg/008.jpg","images/neg/015.jpg","images/neg/016.jpg","images/pos/014.jpg","images/neut/004.jpg","images/neut/015.jpg","images/neg/006.jpg","images/neut/010.jpg","images/neut/009.jpg","images/neut/016.jpg","images/pos/004.jpg","images/neg/011.jpg","images/neut/005.jpg","images/neg/012.jpg","images/pos/016.jpg","images/neut/003.jpg","images/neut/008.jpg"], "values":{"r1": "6", "r2": "5", "r3": "4", "r4": "3", "r5": "3", "r6": "4", "r7": "5", "r8": "6", "r9": "6", "r10": "5", "r11": "4", "r12": "3", "sex": "", "age": "", "income": "", "edu": "", "work": "", "car": "", "city": "", "about": ""}}';

$_json = html_entity_decode($_POST['result']);
$_res = json_decode($_json);
$_ip = html_entity_decode($_POST['ip']);
$_city_name = html_entity_decode($_POST['city_name']);
$_loc = html_entity_decode($_POST['loc']);
$_device = html_entity_decode($_POST['device']);

$_scr = json_decode(html_entity_decode($_POST['scr']));
$_scr_w = $_scr->scr_w;
$_scr_h = $_scr->scr_h;

$_test = json_encode($_res->test);
$_times = json_encode($_res->times);
$_valence = json_encode($_res->valence);
$_imgurl_1 = json_encode($_res->imgurl_1);
$_imgurl_2 = json_encode($_res->imgurl_2);

$_values = $_res->values;
$_r1 = $_values->r1;
$_r2 = $_values->r2;
$_r3 = $_values->r3;
$_r4 = $_values->r4;
$_r5 = $_values->r5;
$_r6 = $_values->r6;
$_r7 = $_values->r7;
$_r8 = $_values->r8;
$_r9 = $_values->r9;
$_r10 = $_values->r10;
$_r11 = $_values->r11;
$_r12 = $_values->r12;
$_sex = $_values->sex;
$_age = $_values->age;
$_income = $_values->income;
$_edu = $_values->edu;
$_work = $_values->work;
$_car = $_values->car;
$_city = $_values->city;
$_about = $_values->about;

//echo "<pre>";
//print_r($_json);
//echo "</pre>";
//JSON.stringify({test, times, valence, imgurl_1, imgurl_2})+values;
//return;

 	$link = mysql_connect('localhost', 'login', 'password');
	if (!$link) {
	    die('Ошибка соединения: ' . mysql_error());
	}

	$db_selected = mysql_select_db('login', $link);
	if (!$db_selected) {
	    die ('Can\'t use foo : ' . mysql_error());
	}

	mysql_set_charset("utf8");

	$sql_insert = "INSERT INTO `img` (`json`,`ip`,`city_name`,`loc`,`test`,`times`,`valence`,`imgurl_1`,`imgurl_2`,
	`r1`,`r2`,`r3`,`r4`,`r5`,`r6`,`r7`,`r8`,`r9`,`r10`,`r11`,`r12`,`sex`,`age`,`income`,`edu`,`work`,`car`,`city`,`about`,`device`,`scr_w`,`scr_h`) VALUES (
	'".$_json."','".$_ip."','".$_city_name."','".$_loc."','".$_test."',
	'".$_times."','".$_valence."','".$_imgurl_1."','".$_imgurl_2."','".$_r1."',
	'".$_r2."','".$_r3."','".$_r4."','".$_r5."','".$_r6."','".$_r7."','".$_r8."','".$_r9."','".$_r10."','".$_r11."','".$_r12."',
	'".$_sex."','".$_age."','".$_income."','".$_edu."','".$_work."','".$_car."','".$_city."','".$_about."','".$_device."','".$_scr_w."','".$_scr_h."')";

	if (mysql_query($sql_insert)) {
	 echo "<style>body {color: #eee; background: black;}</style><center><br /> Благодарим за участие! <br /> Если остались вопросы - напишите нам sno_inueco@mail.ru <br /></center>";
	    //sleep(1);
	} else {
	    echo "Error: " . $sql_insert . "<br>" . mysql_error($link);
	    print_r(mysql_error($link));
	}
	mysql_close($link);

?>